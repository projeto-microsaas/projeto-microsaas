const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const User = require('../models/User');

const router = express.Router();

router.post('/login', asyncHandler(async (req, res) => {
  const { email, password, role } = req.body;
  console.log('Dados recebidos no login:', { email, password, role });

  if (!email || !password || !role) {
    return res.status(400).json({ message: 'Email, senha e função são obrigatórios' });
  }

  const user = await User.findOne({ email });

  if (!user) {
    return res.status(400).json({ message: 'Usuário não encontrado' });
  }

  if (user.role !== role) {
    return res.status(400).json({ message: 'Função inválida para este usuário' });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ message: 'Senha inválida' });
  }

  const token = jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  );

  res.json({
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    }
  });
}));

module.exports = router;
