"devDependencies": {
  "tailwindcss": "^3.4.3",
  "postcss": "^8.4.38",
  "autoprefixer": "^10.4.19"
}
