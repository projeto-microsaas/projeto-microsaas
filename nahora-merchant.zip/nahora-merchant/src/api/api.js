const API_BASE_URL = "http://localhost:5000/api";

const getAuthHeaders = () => {
  const token = localStorage.getItem("authToken");
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
};

export const login = async (email, password, role) => {
  const body = { email, password, role };
  console.log('Valores recebidos na função login:', { email, password, role });
  console.log('Dados enviados para o login:', body);
  console.log('Corpo serializado:', JSON.stringify(body));
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Falha na autenticação");
  }
  return response.json();
};

export const getUser = async () => {
  const response = await fetch(`${API_BASE_URL}/users/me`, {
    headers: getAuthHeaders(),
  });
  if (!response.ok) throw new Error("Erro ao buscar usuário");
  return response.json();
};

export const updateUser = async (data) => {
  const response = await fetch(`${API_BASE_URL}/users/me`, {
    method: "PUT",
    headers: getAuthHeaders(),
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Erro ao atualizar usuário");
  return response.json();
};

export const getOrders = async () => {
  const response = await fetch(`${API_BASE_URL}/orders`, {
    headers: getAuthHeaders(),
  });
  if (!response.ok) throw new Error("Erro ao buscar pedidos");
  return response.json();
};

export const createOrder = async (orderData) => {
  const response = await fetch(`${API_BASE_URL}/orders`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(orderData),
  });
  if (!response.ok) throw new Error("Erro ao criar pedido");
  return response.json();
};

export const acceptOrder = async (orderId) => {
  const response = await fetch(`${API_BASE_URL}/orders/${orderId}/accept`, {
    method: "PUT",
    headers: getAuthHeaders(),
  });
  if (!response.ok) throw new Error("Erro ao aceitar pedido");
  return response.json();
};

export const getDrivers = async () => {
  const response = await fetch(`${API_BASE_URL}/drivers`, {
    headers: getAuthHeaders(),
  });
  if (!response.ok) throw new Error("Erro ao buscar entregadores");
  return response.json();
};