const config = {
    apiBaseUrl: "http://localhost:5000/api",
  };
  export default config;